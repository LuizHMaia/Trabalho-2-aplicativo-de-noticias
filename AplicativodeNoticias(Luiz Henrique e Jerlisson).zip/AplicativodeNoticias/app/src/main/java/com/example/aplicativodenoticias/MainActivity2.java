package com.example.aplicativodenoticias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity implements View.OnClickListener{

    private EditText editTextTextPassword;
    private EditText editTextTextEmailAddress;
    private Button button7;
    private Button button8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        editTextTextPassword = findViewById(R.id.editTextTextPassword);
        editTextTextEmailAddress = findViewById(R.id.editTextTextEmailAddress);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);

        button7.setOnClickListener(this);
        button8.setOnClickListener(this);


    }

    @Override
    public void onClick(View evento) {
        if (evento.getId()==R.id.button7){
            Entrar();
        }else if (evento.getId()==R.id.button8){
            ContentValues cv = new ContentValues();
            cv.put("email", editTextTextEmailAddress.getText().toString());
            cv.put("password", editTextTextPassword.getText().toString());

            DataBaseHelper db = new DataBaseHelper(this);
            String msg = "";

            if (db.inserir(cv)>0){
                msg = "Cadastro realizado com sucesso!";
                editTextTextEmailAddress.setText("");
                editTextTextPassword.setText("");
            }else{
                msg = "Ocorreu um erro durante o cadastro!";
            }
            Toast.makeText(this, msg,Toast.LENGTH_SHORT).show();

        }

    }

    public void Entrar(){
        Intent it = new Intent(this, MainActivity3.class);
        startActivity(it);
    }

}
