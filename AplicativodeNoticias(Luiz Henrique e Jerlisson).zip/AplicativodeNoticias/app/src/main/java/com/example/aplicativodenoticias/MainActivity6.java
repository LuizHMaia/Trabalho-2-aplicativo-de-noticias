package com.example.aplicativodenoticias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity6 extends AppCompatActivity {
    private Button button13;
    private Button btnVoltar3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        button13 = findViewById(R.id.button13);
        btnVoltar3 = findViewById(R.id.btnVoltar3);

        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.button13){
                    Editar();
                }
            }
        });
        btnVoltar3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                    onBackPressed();
            }
        });
    }
    public void Editar(){
        Intent editar = new Intent(this, MainActivity3.class);
        startActivity(editar);
    }
}