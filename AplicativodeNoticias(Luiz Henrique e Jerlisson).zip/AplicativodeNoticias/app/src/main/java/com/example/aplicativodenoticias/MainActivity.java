package com.example.aplicativodenoticias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnCriar;
    private Button button;
    private Button button3;
    private Button button2;
    private Button button4;
    private Button btnGames;
    private Button btnOutros;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        button3 = findViewById(R.id.button3);
        button2 = findViewById(R.id.button2);
        button4 = findViewById(R.id.button4);
        btnGames = findViewById(R.id.btnGames);
        btnOutros = findViewById(R.id.btnOutros);
        btnCriar = findViewById(R.id.btnCriar);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.button){
                    SelecionarPolitica();
                }
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.button3){
                    SelecionarAstrologia();
                }
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.button2){
                    SelecionarBiologia();
                }
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.button4){
                    SelecionarFamosos();
                }
            }
        });
        btnGames.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.btnGames){
                    SelecionarGames();
                }
            }
        });
        btnOutros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.btnOutros){
                    SelecionarOutros();
                }
            }
        });
        btnCriar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.btnCriar){
                    CriarNoticia();
                }
            }
        });


    }
    public void CriarNoticia(){
        Intent criar = new Intent(this, MainActivity2.class);
        startActivity(criar);

    }
    public void SelecionarPolitica(){
        Intent politica = new Intent(this, MainActivity5.class);
        startActivity(politica);

    }
    public void SelecionarAstrologia(){
        Intent astrologia = new Intent(this, MainActivity4.class);
        startActivity(astrologia);

    }
    public void SelecionarBiologia(){
        Intent biologia = new Intent(this, MainActivity6.class);
        startActivity(biologia);

    }
    public void SelecionarFamosos(){
        Intent famosos = new Intent(this, MainActivity8.class);
        startActivity(famosos);

    }
    public void SelecionarGames(){
        Intent games = new Intent(this, MainActivity7.class);
        startActivity(games);

    }
    public void SelecionarOutros(){
        Intent outros = new Intent(this, MainActivity4.class);
        startActivity(outros);

    }
}