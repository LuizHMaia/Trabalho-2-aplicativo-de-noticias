package com.example.aplicativodenoticias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;

public class MainActivity3 extends AppCompatActivity {
    private EditText editTextTextMultiLine;
    private TextInputEditText textInputEditText;
    private Button button9;
    private Button button10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        editTextTextMultiLine = findViewById(R.id.editTextTextEmailAddress);
        textInputEditText = findViewById(R.id.textInputEditText);
        button9 = findViewById(R.id.button9);
        button10 = findViewById(R.id.button10);


        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.button10){
                   Publicar();
                }
            }
        });
    }
    public void Publicar(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}