package com.example.aplicativodenoticias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity8 extends AppCompatActivity {
    private Button button15;
    private Button btnVoltar5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);

        button15 = findViewById(R.id.button15);
        btnVoltar5 = findViewById(R.id.btnVoltar5);

        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                if (evento.getId()==R.id.button15){
                    Editar();
                }
            }
        });
        btnVoltar5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View evento) {
                    onBackPressed();
            }
        });

    }
    public void Editar(){
        Intent editar = new Intent(this, MainActivity3.class);
        startActivity(editar);
    }
}