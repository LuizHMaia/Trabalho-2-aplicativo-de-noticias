package com.example.aplicativodenoticias;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper  extends SQLiteOpenHelper {

    //Atributos
    private static  final  String DATABASE_NAME = "cadastro";
    private static final int DATABASE_VERSION =1;
    private final  String CREATE_TABLE_CADASTRO =
            "CREATE TABLE cadastro(" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "email text," +
                    "senha text)";

    public DataBaseHelper(Context contexto){
        super(contexto,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_CADASTRO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS cadastro");
        onCreate(sqLiteDatabase);
    }

    public  long inserir(ContentValues cv){
        SQLiteDatabase db = this.getWritableDatabase();
        long id = db.insert("cadastro",null,cv);
        return  id;
    }

    public List<ContentValues> ProcurarEmail(String email){
        String sql = "SELECT * FROM cadastro WHERE email lik ?";

        String vetor[] = new String[]{"%",email+"%"};
        return  pesquisar(sql,vetor);
    }

    public List<ContentValues> ProcurarSenha(String senha){
        String sql = "SELECT * FROM cadastro WHERE senha lik ?";

        String vetor[] = new String[]{"%",senha+"%"};
        return  pesquisar(sql,vetor);
    }

    public List<ContentValues> ProcurarTodas(){
        String sql = "SELECT * FROM cadastro ORDER BY id";

        String vetor[] = null;
        return  pesquisar(sql,vetor);
    }



    private List<ContentValues> pesquisar(String sql, String[] vetor) {

        List<ContentValues> lista = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(sql, vetor);
        if (c.moveToFirst()){
            do {
                ContentValues cv = new ContentValues();
                cv.put("id", c.getInt(c.getColumnIndex("id")));
                cv.put("email", c.getInt(c.getColumnIndex("email")));
                cv.put("senha", c.getInt(c.getColumnIndex("senha")));
                lista.add(cv);
            }while (c.moveToNext());
        }

        return null;
    }
}